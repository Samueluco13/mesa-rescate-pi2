(function () {
  'use strict';
  const mount = document.getElementById('rescate-app');
  if (!mount) return;
  const config = window.RA_CONFIG || {};
  const validation = window.RAValidation;
  const pickupMaps = window.RA_PICKUP_MAPS;
  const settings = Object.assign({ brand_name: 'Rescate de Alimentos', tagline: 'Fundación Mesa Común', accent_color: '#D64114', hero_title: 'Buena comida. Nuevas oportunidades.', hero_text: 'Conecta los alimentos que sobran con quienes más los necesitan. Un rescate empieza contigo.', city: 'Cali, Colombia', support_email: '' }, config.settings || {});
  const categories = { all: 'Todo', vegetables: 'Verduras', fruit: 'Frutas', bakery: 'Panadería', prepared: 'Preparados', dairy: 'Lácteos', pantry: 'Despensa' };
  const units = { kg: 'kg', portions: 'porciones', units: 'unidades', liters: 'litros' };
  const statusNames = { available: 'Disponible', reserved: 'Reservada', delivered: 'Entregada' };
  const roleNames = { ra_donor: 'Comercio donante', ra_volunteer: 'Voluntario', ra_coordinator: 'Coordinación', administrator: 'Administración', donor: 'Comercio donante', volunteer: 'Voluntario', coordinator: 'Coordinación' };
  const icons = {
    leaf: '<path d="M19 3c-8-1-14 2-14 8a6 6 0 0 0 6 6c6 0 9-6 8-14Z"/><path d="m4 21 11-11M8 17v-5m3 2h5"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    bag: '<path d="M5 7h14l2 13H3L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    pin: '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    chevron: '<path d="m8 10 4 4 4-4"/>',
    arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 6.1A8 8 0 0 1 20 12M4 12a8 8 0 0 0 13.9 5.9"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    shield: '<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Z"/><path d="m8 12 3 3 5-6"/>',
    box: '<path d="m3 7 9-4 9 4v11l-9 4-9-4V7Z"/><path d="m3 7 9 4 9-4M12 11v11M7 5l10 5"/>',
    vegetables: '<path d="m5 12 7-7 7 7-7 9-7-9Z"/><path d="m12 5 1-3m-1 3 5-2m-5 2L9 2M9 10l3 2m-5 1 3 2"/>',
    fruit: '<path d="M12 7c-4-3-9 0-9 5s4 10 9 7c5 3 9-2 9-7s-5-8-9-5Z"/><path d="M12 7c0-3 2-5 5-5M12 6 9 3"/>',
    bakery: '<path d="M5 7C5 3 19 3 19 7c3 0 3 6 0 6v7H5v-7C2 13 2 7 5 7Z"/><path d="M9 10v5m6-5v5"/>',
    prepared: '<path d="M3 19h18M5 16a7 7 0 0 1 14 0H5ZM12 9V6m-2 0h4"/>',
    dairy: '<path d="M7 3h9v5l3 4v9H5V8l2-5Z"/><path d="M7 3v5h9M5 8h11M16 8v13M5 14h11"/>',
    pantry: '<path d="M6 3h12v4l2 3v11H4V10l2-3V3Z"/><path d="M6 7h12M4 12h16M9 16h6"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    offline: '<path d="m3 3 18 18M2 8a17 17 0 0 1 3-2m4-1a17 17 0 0 1 13 3M5 12a12 12 0 0 1 4-2m5 0a12 12 0 0 1 5 2M9 16a5 5 0 0 1 6 0M12 20h.01"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
    logout: '<path d="M9 4H4v16h5M14 8l4 4-4 4M8 12h13"/>',
    heart: '<path d="M20 5a5 5 0 0 0-8 1 5 5 0 0 0-8-1c-4 5 3 11 8 15 5-4 12-10 8-15Z"/>',
    route: '<circle cx="6" cy="5" r="2"/><circle cx="18" cy="19" r="2"/><path d="M8 5h7a4 4 0 0 1 0 8H9a3 3 0 0 0 0 6h7"/>',
    map: '<path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5ZM9 3v16M15 5v16"/>',
    phone: '<path d="m5 3 4 4-2 3a16 16 0 0 0 7 7l3-2 4 4-2 3C10 23 1 14 2 5l3-2Z"/>'
  };
  const icon = (name, cls) => '<svg' + (cls ? ' class="' + cls + '"' : '') + ' viewBox="0 0 24 24" aria-hidden="true">' + (icons[name] || icons.leaf) + '</svg>';
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const safeUrl = value => { try { const u = new URL(value || '', window.location.href); return ['http:', 'https:'].includes(u.protocol) ? u.href : '#'; } catch (_) { return '#'; } };
  const asset = filename => String(config.assetsUrl || '').replace(/\/$/, '') + '/images/' + filename + '?ver=' + encodeURIComponent(config.cacheVersion || config.appVersion || '2.0.0');
  const imageFor = category => asset('v2/' + (categories[category] ? category : 'vegetables') + '.webp');
  const read = key => { try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (_) { return null; } };
  const save = (key, data) => { try { sessionStorage.setItem(key, JSON.stringify(data)); } catch (_) {} };
  const remove = key => { try { sessionStorage.removeItem(key); } catch (_) {} };
  const requestKey = () => window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : 'ra-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  const state = { user: config.user || null, capabilities: {}, page: 'explore', category: 'all', search: '', status: 'all', list: [], loading: true, error: null, stale: false, offline: !navigator.onLine, success: null, dialog: null, lastFocus: null, listRequest: 0, serverOffset: 0 };
  let toastTimer;
  const serverNow = () => Date.now() + state.serverOffset;
  function syncClock(value) { const d = normalizedDate(value); if (d) state.serverOffset = d.valueOf() - Date.now(); }
  function uid() { return state.user ? Number(state.user.id) : 0; }
  function key(suffix) { return 'rescate-' + uid() + '-' + suffix; }
  function normalizedDate(value) { if (!value) return null; const v = String(value); const d = new Date(/^\d{4}-\d{2}-\d{2} \d{2}:/.test(v) ? v.replace(' ', 'T') + 'Z' : v); return Number.isNaN(d.valueOf()) ? null : d; }
  function formatDate(value, short) { const d = normalizedDate(value); if (!d) return 'Sin fecha'; return new Intl.DateTimeFormat('es-CO', short ? { timeZone: 'America/Bogota', hour: 'numeric', minute: '2-digit' } : { timeZone: 'America/Bogota', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }).format(d); }
  function deadlineLabel(item) { const d = normalizedDate(item.deadline); if (!d) return 'Consultar horario'; const today = new Intl.DateTimeFormat('en-CA', {timeZone:'America/Bogota'}).format(new Date(serverNow())); const date = new Intl.DateTimeFormat('en-CA', {timeZone:'America/Bogota'}).format(d); return (today === date ? 'Hoy, ' : formatDate(item.deadline, false).split(',')[0] + ', ') + formatDate(item.deadline, true); }
  function expired(item) { const d = normalizedDate(item.deadline); return item.status === 'available' && d && d.valueOf() <= serverNow(); }
  function dateLocal(value) { const d = normalizedDate(value); if (!d) return ''; const parts = new Intl.DateTimeFormat('sv-SE', { timeZone: 'America/Bogota', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(d); return parts.replace(' ', 'T'); }
  function isoLocal(value) { return value ? value + (String(value).length === 16 ? ':00' : '') + '-05:00' : ''; }
  function quantity(item) { return new Intl.NumberFormat('es-CO', { maximumFractionDigits: 3 }).format(Number(item.quantity) || 0) + ' ' + (units[item.unit] || item.unit || ''); }
  function role() { return roleNames[state.user && state.user.role] || (state.capabilities.coordinate ? 'Coordinación' : state.capabilities.create ? 'Comercio donante' : 'Voluntario'); }
  function initials(name) { return String(name || 'U').split(/\s+/).filter(Boolean).slice(0, 2).map(n => n[0]).join('').toUpperCase(); }
  function donationId(item) { return '#' + String(item.id).padStart(4, '0'); }
  function unwrap(data) { return data && data.item ? data.item : data; }
  async function api(path, options) {
    const abort = new AbortController();
    const timeout = setTimeout(() => abort.abort(), 22000);
    try {
      const response = await fetch(String(config.apiUrl || '/wp-json/rescate/v1/').replace(/\/$/, '') + '/' + path.replace(/^\//, ''), Object.assign({ credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' }, signal: abort.signal, cache: 'no-store' }, options || {}));
      let data;
      try { data = await response.json(); } catch (_) { throw Object.assign(new Error('El servidor no pudo confirmar la operación. Reintenta con esta misma solicitud.'), { uncertain: true }); }
      if (!response.ok) {
        const error = validation ? validation.normalizeApiError(data, response.status) : {message:'No pudimos completar esta acción. Recarga la página y vuelve a intentar.',status:response.status,uncertain:response.status>=500};
        throw Object.assign(new Error(error.message), error);
      }
      return data;
    } catch (error) {
      if (!error.status) { error.uncertain = true; error.message = navigator.onLine ? 'No recibimos confirmación del servidor. Reintenta con esta misma solicitud.' : 'No hay conexión. Conservamos la solicitud para que puedas reintentar.'; }
      throw error;
    } finally { clearTimeout(timeout); }
  }
  function brand(mobile) {
    const logo = settings.logo_url ? safeUrl(settings.logo_url) : asset('rescate-mark.svg');
    return '<button class="ra-brand' + (mobile ? ' ra-mobile-brand' : '') + '" data-action="navigate" data-page="explore" aria-label="' + esc(settings.brand_name) + ', inicio"><img src="' + esc(logo) + '" alt="" width="44" height="44"><span class="ra-brand-copy"><span class="ra-brand-word">' + esc(settings.brand_name === 'Rescate de Alimentos' ? 'Rescate' : settings.brand_name) + '</span><span class="ra-brand-sub">' + esc(settings.tagline) + '</span></span></button>';
  }
  function navItems() { const items = [{ page: 'explore', label: 'Explorar', icon: 'grid' }, { page: 'mine', label: state.capabilities.coordinate ? 'Operación' : 'Mis rescates', icon: 'bag' }]; if (state.capabilities.create) items.push({ page: 'donate', label: 'Donar alimentos', mobileLabel: 'Donar', icon: 'plus' }); items.push({ page: 'account', label: 'Mi cuenta', mobileLabel: 'Cuenta', icon: 'user' }); return items; }
  function navigation(mobile) {
    return navItems().map(item => '<button class="' + (mobile ? 'ra-bottom-item' : 'ra-nav-item') + (state.page === item.page ? ' is-active' : '') + '" data-action="navigate" data-page="' + item.page + '"' + (state.page === item.page ? ' aria-current="page"' : '') + ' aria-label="' + esc(item.label) + '"><span class="ra-nav-symbol">' + icon(item.icon) + '</span><span>' + esc(mobile ? item.mobileLabel || item.label : item.label) + '</span></button>').join('');
  }
  function shell() {
    const auth = !!uid();
    const firstName = auth ? String(state.user.name || '').split(/\s+/)[0] : '';
    return '<div class="ra-shell"><aside class="ra-sidebar" aria-label="Navegación principal">' + brand(false) + '<nav class="ra-navigation">' + (auth ? navigation(false) : '<a class="ra-nav-item is-active" href="' + esc(safeUrl(config.loginUrl)) + '"><span class="ra-nav-symbol">' + icon('user') + '</span><span>Ingresar a Rescate</span></a>') + '</nav><div class="ra-sidebar-bottom"><div class="ra-sidebar-note"><img src="' + esc(asset('v2/promo.webp')) + '" alt="" width="360" height="180"><strong>La comida tiene<br>mucho por compartir.</strong><p>Una recogida puede ser el comienzo de algo bueno.</p><button class="ra-link-button" data-action="help">Conoce el proceso ' + icon('arrow') + '</button></div><div class="ra-sidebar-footer">' + esc(settings.tagline) + '<span>Desarrollado por Moreno Technology</span></div></div></aside><main class="ra-main" id="ra-main" tabindex="-1"><header class="ra-topbar"><div class="ra-mobile-header">' + brand(true) + '<div class="ra-greeting"><p>' + (auth ? 'Hola, ' + esc(firstName) : 'Bienvenido a Rescate') + '</p><strong>' + esc(settings.brand_name) + '</strong><span>' + icon('pin') + esc(settings.city) + '</span></div></div><div class="ra-top-actions"><button class="ra-header-help" data-action="help" aria-label="Cómo funciona Rescate">' + icon('info') + '</button>' + (auth ? '<button class="ra-profile-button" data-action="navigate" data-page="account" aria-label="Ver mi cuenta"><span class="ra-avatar">' + esc(initials(state.user.name)) + '</span><span class="ra-profile-copy"><strong>' + esc(state.user.name) + '</strong><small>' + esc(role()) + '</small></span></button>' : '<a class="ra-icon-button ra-login-link" href="' + esc(safeUrl(config.loginUrl)) + '" aria-label="Ingresar a mi cuenta">' + icon('user') + '</a>') + '</div></header><div id="ra-demo"></div><div id="ra-content"></div><footer class="ra-footer"><span><strong>' + esc(settings.brand_name) + '</strong> · ' + esc(settings.tagline) + '</span><span class="ra-powered">Desarrollado por Moreno Technology</span><span class="ra-connection' + (state.offline ? ' is-offline' : '') + '">' + (state.offline ? 'Sin conexión' : 'Guardado seguro en el servidor') + '</span></footer></main>' + (auth ? '<nav class="ra-bottom-nav" aria-label="Navegación móvil">' + navigation(true) + '</nav>' : '<nav class="ra-bottom-nav ra-guest-nav" aria-label="Acceso a Rescate"><button class="ra-bottom-item is-active" data-action="navigate" data-page="explore"><span class="ra-nav-symbol">' + icon('grid') + '</span><span>Inicio</span></button><button class="ra-bottom-item" data-action="help"><span class="ra-nav-symbol">' + icon('heart') + '</span><span>Cómo funciona</span></button><a class="ra-bottom-item" href="' + esc(safeUrl(config.loginUrl)) + '"><span class="ra-nav-symbol">' + icon('user') + '</span><span>Ingresar</span></a></nav>') + '</div><div id="ra-dialog-region"></div><div id="ra-toast-region" aria-live="polite" aria-atomic="true"></div>';
  }
  function hero(guest) {
    return '<section class="ra-hero" aria-label="Comparte alimentos en buen estado"><img class="ra-hero-image" src="' + esc(asset('v2/hero.webp')) + '" alt="Alimentos frescos preparados para compartir" width="1440" height="720" fetchpriority="high"><div class="ra-hero-copy"><h1>' + esc(settings.hero_title) + '</h1><p>' + esc(settings.hero_text) + '</p>' + (guest ? '<a class="ra-button ra-hero-button" href="' + esc(safeUrl(config.loginUrl)) + '">Quiero participar <span class="ra-action-arrow">' + icon('arrow') + '</span></a>' : '<button class="ra-button ra-hero-button" data-action="' + (state.capabilities.create ? 'navigate' : 'show-offers') + '"' + (state.capabilities.create ? ' data-page="donate"' : '') + '>' + (state.capabilities.create ? 'Donar alimentos' : 'Ver rescates') + '<span class="ra-action-arrow">' + icon('arrow') + '</span></button>') + '</div></section>';
  }
  function promoBanner() {
    return '<section class="ra-promo"><img src="' + esc(asset('v2/promo.webp')) + '" alt="Alimentos de panadería listos para compartir" width="1440" height="720" loading="lazy"><div><h2>Lo bueno<br>se comparte.</h2><p>Conecta una donación con una nueva mesa.</p><button class="ra-button ra-button-light" data-action="' + (state.capabilities.create ? 'navigate' : 'help') + '"' + (state.capabilities.create ? ' data-page="donate"' : '') + '>' + (state.capabilities.create ? 'Publicar donación' : 'Así funciona') + icon('arrow') + '</button></div></section>';
  }
  function guestPage() {
    return '<div class="ra-guest-intro"><p>Comida en buen estado. Un destino mejor.</p><a class="ra-guest-access" href="' + esc(safeUrl(config.loginUrl)) + '">' + icon('user') + 'Ingresa para participar' + icon('arrow') + '</a></div>' + hero(true) + '<section class="ra-guest-categories" aria-label="Alimentos para compartir">' + ['vegetables','fruit','bakery','prepared','dairy','pantry'].map(cat => '<div class="ra-guest-category"><img src="' + esc(imageFor(cat)) + '" alt="" width="100" height="100"><span>' + esc(categories[cat]) + '</span></div>').join('') + '</section><div class="ra-login-layout"><section class="ra-login-card"><span class="ra-login-symbol">' + icon('heart') + '</span><h2>Una buena oportunidad empieza contigo.</h2><p>Ingresa para compartir alimentos, reservar una recogida o acompañar cada rescate hasta su entrega.</p><a class="ra-button" href="' + esc(safeUrl(config.loginUrl)) + '">Ingresar a mi cuenta ' + icon('arrow') + '</a><small>El acceso es para comercios, voluntarios y coordinación de la fundación. Solicita tu cuenta a la coordinación.</small>' + (settings.support_email ? '<a class="ra-link-button" href="mailto:' + esc(settings.support_email) + '">Solicitar acceso</a>' : '') + '</section><section class="ra-guest-story"><h2>Del comercio<br>a una nueva mesa.</h2><ol class="ra-how-list"><li><span class="ra-how-number">1</span><div><strong>Comparte lo que está bueno</strong><p>El comercio publica el alimento y el horario de recogida.</p></div></li><li><span class="ra-how-number">2</span><div><strong>Un voluntario lo recoge</strong><p>Una reserva confirmada asigna una sola persona.</p></div></li><li><span class="ra-how-number">3</span><div><strong>La fundación confirma</strong><p>La coordinación registra la recepción de los alimentos.</p></div></li></ol><button class="ra-link-button" data-action="help">Conocer el proceso ' + icon('arrow') + '</button></section></div>' + promoBanner();
  }
  function render() {
    if (pickupMaps) pickupMaps.destroy(mount);
    const focused = document.activeElement;
    const focusId = focused && focused.id;
    const selection = focused && typeof focused.selectionStart === 'number' ? focused.selectionStart : null;
    mount.innerHTML = shell(); mount.setAttribute('aria-busy', 'false');
    renderContent();
    if (focusId) { const target = document.getElementById(focusId); if (target) { target.focus({ preventScroll: true }); if (selection != null && target.setSelectionRange) { try { target.setSelectionRange(selection, selection); } catch (_) {} } } }
    if (state.dialog) renderDialog(false);
  }
  function renderContent() {
    const content = document.getElementById('ra-content'); if (!content) return;
    if (!uid()) content.innerHTML = guestPage();
    else if (state.success) content.innerHTML = successPage(state.success);
    else if (state.page === 'donate') content.innerHTML = donationPage();
    else if (state.page === 'account') content.innerHTML = accountPage();
    else if (state.page === 'mine') content.innerHTML = minePage();
    else content.innerHTML = explorePage();
    const demo = document.getElementById('ra-demo');
    if (demo) demo.innerHTML = config.isDemo || state.list.some(i => i.is_demo) ? '<div class="ra-demo-banner">' + icon('info') + '<span>Datos de demostración. Estos alimentos no corresponden a ofertas reales.</span></div>' : '';
  }
  function searchRow() {
    return '<div class="ra-search-row"><div class="ra-search">' + icon('search') + '<label class="ra-sr" for="ra-search">Buscar alimento, comercio o barrio</label><input id="ra-search" type="search" placeholder="¿Qué vas a rescatar hoy?" value="' + esc(state.search) + '" autocomplete="off"></div><button class="ra-refresh" data-action="refresh" aria-label="Actualizar donaciones">' + icon('refresh') + '<span>Actualizar</span></button></div>';
  }
  function categoryRow() {
    return '<div class="ra-categories" role="group" aria-label="Categorías de alimentos">' + Object.entries(categories).map(([value,label]) => '<button class="ra-category' + (state.category === value ? ' is-active' : '') + '" data-action="category" data-category="' + value + '" aria-pressed="' + (state.category === value) + '"><span class="ra-category-photo"><img src="' + esc(imageFor(value === 'all' ? 'prepared' : value)) + '" alt="" width="112" height="112" loading="lazy"></span><span>' + esc(label) + '</span></button>').join('') + '</div>';
  }
  function sidePanel() { return '<aside><section class="ra-side-panel"><div class="ra-side-panel-icon">' + icon('route') + '</div><h3>Una recogida.<br>Un gran comienzo.</h3><p>Así funciona un rescate de alimentos.</p><ol class="ra-how-list"><li><span class="ra-how-number">1</span><div><strong>Elige una donación</strong><p>Revisa el alimento, el lugar y la hora límite.</p></div></li><li><span class="ra-how-number">2</span><div><strong>Reserva tu recogida</strong><p>La donación queda asignada únicamente a ti.</p></div></li><li><span class="ra-how-number">3</span><div><strong>Coordina la entrega</strong><p>La fundación confirma la recepción y cierra el rescate.</p></div></li></ol><p class="ra-side-footnote">Reserva solo si puedes recoger dentro del horario indicado.</p></section><p class="ra-privacy-note">' + icon('shield') + '<span>Cada reserva se confirma de forma segura para evitar recogidas duplicadas.</span></p></aside>'; }
  function explorePage() {
    return searchRow() + hero(false) + categoryRow() + '<section id="ra-offers" aria-label="Donaciones disponibles"><div class="ra-page-heading ra-offers-heading"><div><h2>Listos para rescatar</h2><p id="ra-list-status" role="status" aria-live="polite">' + (state.loading ? 'Actualizando donaciones…' : 'Consulta actualizada') + '</p></div><button class="ra-link-button" data-action="clear-filters">Ver todo ' + icon('arrow') + '</button></div><div id="ra-results">' + results() + '</div></section>' + promoBanner();
  }
  function minePage() { return '<div class="ra-page-heading"><div><h1>' + (state.capabilities.coordinate ? 'La operación, en un solo lugar' : 'Cada rescate cuenta') + '</h1><p>' + (state.capabilities.coordinate ? 'Consulta los registros y confirma las entregas recibidas.' : 'Consulta tus donaciones y sigue cada recogida hasta su entrega.') + '</p></div>' + (state.capabilities.create ? '<button class="ra-button" data-action="navigate" data-page="donate">' + icon('plus') + 'Donar alimentos</button>' : '') + '</div><form class="ra-lookup" id="ra-lookup-form" novalidate><label class="ra-sr" for="ra-lookup-id">Identificador de la donación</label><input id="ra-lookup-id" name="donation_id" type="text" inputmode="numeric" aria-describedby="ra-help-donation_id ra-error-donation_id" pattern="#?[0-9]+" placeholder="Consultar por ID, p. ej. 24" required><button class="ra-button ra-button-secondary" type="submit">Consultar estado</button><small class="ra-lookup-help" id="ra-help-donation_id">Usa el número de la donación, por ejemplo 24 o #24.</small><span class="ra-field-error" id="ra-error-donation_id"></span><div id="ra-lookup-error" class="ra-form-error" role="alert"></div></form>' + searchRow() + '<div class="ra-tabs" role="group" aria-label="Filtrar por estado">' + [['all', 'Todos'], ['available', 'Disponibles'], ['reserved', 'Reservadas'], ['delivered', 'Entregadas']].map(([value, label]) => '<button class="ra-tab' + (state.status === value ? ' is-active' : '') + '" data-action="status" data-status="' + value + '" aria-pressed="' + (state.status === value) + '">' + label + '</button>').join('') + '</div><div id="ra-results">' + results() + '</div>'; }
  function visibleItems() { const query = state.search.trim().toLocaleLowerCase('es'); return state.list.filter(item => (state.page !== 'explore' || item.status === 'available' && !expired(item)) && (state.page !== 'explore' || state.category === 'all' || item.category === state.category) && (state.page !== 'mine' || state.status === 'all' || item.status === state.status) && (!query || [item.title, item.description, item.merchant_name, item.pickup_address, item.pickup_area].join(' ').toLocaleLowerCase('es').includes(query))); }
  function results() {
    let html = '';
    if (state.error) html += '<div class="ra-alert ra-alert-error" role="alert">' + icon('offline') + '<span>No pudimos actualizar las donaciones.' + (state.stale ? ' Esta es información anterior; actualiza antes de reservar.' : '') + '</span><button class="ra-link-button" data-action="refresh">Reintentar</button></div>';
    if (state.loading && !state.list.length) return '<p class="ra-loading-text" role="status"><span class="ra-loading-mark"></span>Cargando donaciones…</p><div class="ra-loading-grid" aria-hidden="true"><div class="ra-skeleton"></div><div class="ra-skeleton"></div></div>';
    const items = visibleItems();
    if (!items.length && state.error) return html + '<div class="ra-state">' + icon('offline') + '<h3>No recibimos la lista actualizada</h3><p>Comprueba tu conexión y vuelve a intentarlo. No se han confirmado cambios en tus rescates.</p><button class="ra-button" data-action="refresh">Reintentar</button></div>';
    if (!items.length) return html + '<div class="ra-state">' + icon('bag') + '<h3>' + (state.search || state.category !== 'all' ? 'No encontramos coincidencias' : state.page === 'explore' ? 'No hay donaciones disponibles' : 'Aquí aparecerán tus rescates') + '</h3><p>' + (state.search || state.category !== 'all' ? 'Prueba con otro alimento o consulta todas las categorías.' : state.page === 'explore' ? 'Vuelve a consultar más tarde. Cada nueva donación es otra oportunidad de compartir.' : state.capabilities.create ? 'Publica tu primera donación y acompaña su recorrido.' : 'Explora las donaciones disponibles y reserva una recogida que puedas realizar.') + '</p><button class="ra-button ra-button-secondary" data-action="' + (state.search || state.category !== 'all' ? 'clear-filters' : state.page === 'explore' ? 'refresh' : 'navigate') + '"' + (state.page === 'mine' ? ' data-page="' + (state.capabilities.create ? 'donate' : 'explore') + '"' : '') + '>' + (state.search || state.category !== 'all' ? 'Ver todo' : state.page === 'explore' ? 'Actualizar donaciones' : state.capabilities.create ? 'Publicar una donación' : 'Explorar donaciones') + '</button></div>';
    return html + (state.stale && !state.error ? '<div class="ra-alert">' + icon('info') + '<span>Información anterior. Actualiza para consultar la disponibilidad.</span></div>' : '') + '<div class="ra-donation-grid">' + items.map(card).join('') + '</div>';
  }
  function statusBadge(item) { const ex = expired(item); return '<span class="ra-status ra-status-' + esc(ex ? 'expired' : item.status) + '">' + esc(ex ? 'Hora límite vencida' : statusNames[item.status] || 'Consultar estado') + '</span>'; }
  function card(item) {
    return '<article class="ra-card"><button class="ra-card-action" data-action="detail" data-id="' + Number(item.id) + '" aria-label="Ver ' + esc(item.title) + ', ' + esc(statusNames[item.status] || '') + '"><div class="ra-card-image"><img src="' + esc(imageFor(item.category)) + '" alt="" width="640" height="640" loading="lazy">' + statusBadge(item) + '</div><div class="ra-card-body"><h3>' + esc(item.title) + '</h3><span class="ra-merchant">' + esc(item.merchant_name) + '</span><p class="ra-card-location">' + icon('pin') + '<span>' + esc(item.pickup_area || item.pickup_address) + '</span></p><p class="ra-card-time">' + icon('clock') + '<span>' + esc(item.status === 'delivered' ? 'Entrega confirmada' : deadlineLabel(item)) + '</span></p><div class="ra-card-bottom"><strong class="ra-card-quantity">' + esc(quantity(item)) + '</strong><span class="ra-card-open">' + icon('arrow') + '</span></div></div></button><button class="ra-card-map" data-action="map-detail" data-id="' + Number(item.id) + '" aria-label="' + (item.is_demo ? 'Ver mapa de ejemplo' : 'Ver mapa y ruta de recogida') + ' de ' + esc(item.title) + '">' + icon('map') + '<span>' + (item.is_demo ? 'Mapa de ejemplo' : 'Mapa y ruta') + '</span>' + icon('arrow') + '</button></article>';
  }
  function field(name, label, type, value, extra) {
    const a = extra || {}; const wide = a.wide ? ' ra-field-wide' : ''; const optional = a.optional ? '<span>Opcional</span>' : '';
    const describedBy = ' aria-describedby="' + (a.help ? 'ra-help-' + name + ' ' : '') + 'ra-error-' + name + '"';
    let input;
    if (type === 'textarea') input = '<textarea id="ra-' + name + '" name="' + name + '" rows="3"' + describedBy + (a.required ? ' required' : '') + (a.max ? ' maxlength="' + a.max + '"' : '') + '>' + esc(value) + '</textarea>';
    else if (type === 'select') input = '<select id="ra-' + name + '" name="' + name + '"' + describedBy + (a.required ? ' required' : '') + '>' + (a.options || []).map(([v,l]) => '<option value="' + esc(v) + '"' + (String(v) === String(value) ? ' selected' : '') + '>' + esc(l) + '</option>').join('') + '</select>';
    else input = '<input id="ra-' + name + '" name="' + name + '" type="' + type + '" value="' + esc(value) + '"' + describedBy + (a.required ? ' required' : '') + (a.min != null ? ' min="' + esc(a.min) + '"' : '') + (a.max != null ? (type === 'number' || type === 'datetime-local' ? ' max="' : ' maxlength="') + esc(a.max) + '"' : '') + (a.step ? ' step="' + a.step + '"' : '') + (a.placeholder ? ' placeholder="' + esc(a.placeholder) + '"' : '') + '>';
    return '<div class="ra-field' + wide + '"><label for="ra-' + name + '">' + esc(label) + optional + '</label>' + input + (a.help ? '<small id="ra-help-' + name + '">' + esc(a.help) + '</small>' : '') + '<span class="ra-field-error" id="ra-error-' + name + '"></span></div>';
  }
  function donationPage() {
    if (!state.capabilities.create) return '<div class="ra-state">' + icon('shield') + '<h3>Tu cuenta participa recogiendo</h3><p>Los comercios y la coordinación publican los alimentos. Encuentra una donación para tu próximo rescate.</p><button class="ra-button" data-action="navigate" data-page="explore">Explorar donaciones</button></div>';
    const pending = read(key('create-pending')); const data = pending ? pending.form : read(key('draft')) || {};
    const assisted = state.capabilities.coordinate;
    return '<div class="ra-page-heading"><div><h1>Comparte una nueva oportunidad</h1><p>Publica los alimentos disponibles y coordina su recogida.</p></div></div><div class="ra-form-layout"><form id="ra-donation-form" class="ra-form-panel" novalidate>' + (pending ? '<div class="ra-alert">' + icon('info') + '<span>Hay una publicación pendiente de confirmación. Reintenta la misma solicitud antes de cambiar sus datos.</span></div>' : '') + '<fieldset class="ra-form-fields"' + (pending ? ' disabled' : '') + ' style="border:0;padding:0;margin:0;min-width:0"><section class="ra-form-section"><h2>¿Qué alimentos vas a compartir?</h2><div class="ra-form-grid">' + field('title', 'Nombre del alimento', 'text', data.title || '', {required:true,wide:true,max:180,placeholder:'Por ejemplo: verduras frescas variadas'}) + field('category', 'Categoría', 'select', data.category || 'vegetables', {required:true,options:Object.entries(categories).filter(([k]) => k !== 'all')}) + field('quantity', 'Cantidad disponible', 'number', data.quantity || '', {required:true,min:.001,max:1000000,step:.001,help:'Entre 0.001 y 1.000.000, con un máximo de tres decimales.',placeholder:'Ej. 8'}) + field('unit', 'Unidad de medida', 'select', data.unit || 'kg', {required:true,options:Object.entries(units)}) + field('description', 'Detalles y conservación', 'textarea', data.description || '', {wide:true,optional:true,max:1800,help:'Indica condiciones de conservación o información útil para la recogida.'}) + '</div></section><section class="ra-form-section"><h2>Organiza la recogida</h2><div class="ra-form-grid">' + field('merchant_name', assisted ? 'Comercio que dona' : 'Nombre de tu comercio', 'text', data.merchant_name || (!assisted && state.user.name) || '', {required:true,wide:true,max:180,placeholder:'Nombre del comercio de origen'}) + field('pickup_address', 'Dirección de recogida', 'text', data.pickup_address || '', {required:true,wide:true,max:255,placeholder:'Calle, número y punto de encuentro'}) + field('pickup_area', 'Barrio o sector', 'text', data.pickup_area || '', {optional:true,max:120,placeholder:'Ej. San Fernando'}) + field('deadline', 'Recoger antes de', 'datetime-local', data.deadline || '', {required:true,help:'Fecha y hora de Colombia (UTC−5).'}) + (pickupMaps ? pickupMaps.fieldHTML(data) : '') + (assisted ? field('origin_channel', 'Canal de la solicitud', 'select', data.origin_channel || 'phone', {required:true,wide:true,options:[['web','Web / presencial'],['phone','Llamada telefónica'],['sms','Mensaje SMS']],help:'Registro asistido: se conserva el comercio de origen y tu autoría.'}) : '') + '</div></section><section class="ra-form-section"><label class="ra-checkbox"><input id="ra-food_safe" type="checkbox" name="food_safe" aria-describedby="ra-error-food_safe" required' + (data.food_safe ? ' checked' : '') + '><span>Confirmo que los alimentos están en buen estado para su consumo y que la información de recogida es correcta.</span></label><span class="ra-field-error" id="ra-error-food_safe"></span></section></fieldset><div id="ra-form-error" class="ra-form-error" role="alert"></div><div class="ra-form-actions"><p>La donación se publica únicamente después de recibir la confirmación del servidor.</p><button class="ra-button" type="submit">' + (pending ? 'Reintentar publicación' : 'Publicar donación') + icon('arrow') + '</button></div><p class="ra-draft-status" id="ra-draft-status">' + (pending ? 'Solicitud conservada para reintentar sin duplicar.' : data.title ? 'Borrador recuperado en este dispositivo.' : 'Los campos obligatorios permiten organizar una recogida segura.') + '</p></form><aside class="ra-form-note">' + icon('leaf') + '<h3>Lo que está bueno,<br>puede llegar más lejos.</h3><p>Publica una cantidad real y una hora límite que permita realizar la recogida. La fundación coordinará el destino de los alimentos.</p><p>Una donación reservada deja de ofrecerse a otros voluntarios. Así, cada recogida tiene una sola persona responsable.</p>' + (assisted ? '<p>El registro asistido permite acompañar a los comercios que reciben solicitudes por llamada o SMS.</p>' : '') + '</aside></div>';
  }
  function successPage(item) { return '<section class="ra-success"><div class="ra-success-symbol">' + icon('check') + '</div><h2>Tu donación ya está publicada</h2><p>El servidor confirmó el registro. Ya puedes consultar su estado.</p><div class="ra-success-details"><strong>' + esc(donationId(item)) + ' · ' + esc(item.title) + '</strong><p>' + esc(quantity(item)) + ' · ' + esc(item.merchant_name) + '</p><p>Recoger antes de ' + esc(formatDate(item.deadline)) + '</p></div><div class="ra-success-actions"><button class="ra-button" data-action="detail" data-id="' + Number(item.id) + '">Ver donación ' + icon('arrow') + '</button><button class="ra-button ra-button-secondary" data-action="navigate" data-page="mine">Mis donaciones</button></div></section>'; }
  function accountPage() { return '<div class="ra-page-heading"><div><h1>Tu cuenta, tu comunidad</h1><p>Tu participación conecta los alimentos con una nueva mesa.</p></div></div><section class="ra-account"><div class="ra-account-header"><span class="ra-avatar">' + esc(initials(state.user.name)) + '</span><div><h2>' + esc(state.user.name) + '</h2><p>' + esc(role()) + '</p></div></div><div class="ra-account-list"><div class="ra-account-row">' + icon('shield') + '<div><strong>Tu participación</strong><p>' + (state.capabilities.coordinate ? 'Puedes registrar solicitudes asistidas, supervisar los rescates y confirmar las entregas.' : state.capabilities.create ? 'Puedes publicar alimentos y consultar el estado de las donaciones de tu comercio.' : 'Puedes consultar alimentos disponibles, reservar su recogida y seguir tus rescates.') + '</p></div></div><div class="ra-account-row">' + icon('pin') + '<div><strong>Comunidad</strong><p>' + esc(settings.city) + ' · ' + esc(settings.tagline) + '</p></div></div><div class="ra-account-row">' + icon('info') + '<div><strong>Una recogida bien coordinada</strong><p>Reserva solo si puedes cumplir la hora límite. La coordinación verifica la capacidad de la organización receptora y registra la entrega.</p><button class="ra-link-button" data-action="help">Conocer el proceso</button></div></div>' + (settings.support_email ? '<div class="ra-account-row">' + icon('mail') + '<div><strong>Estamos para ayudarte</strong><p><a href="mailto:' + esc(settings.support_email) + '">' + esc(settings.support_email) + '</a></p></div></div>' : '') + '</div><a class="ra-button ra-button-light" href="' + esc(safeUrl(config.logoutUrl)) + '">' + icon('logout') + 'Cerrar sesión</a></section>'; }
  function navigate(page) { if (!['explore','mine','donate','account'].includes(page)) return; closeDialog(); ++state.listRequest; state.page = page; state.success = null; state.search = ''; state.category = 'all'; state.status = 'all'; state.list = []; state.error = null; state.stale = false; state.loading = ['explore','mine'].includes(page); render(); window.scrollTo({top:0,behavior:'instant'}); const main = document.getElementById('ra-main'); if (main) main.focus({preventScroll:true}); if (state.loading) loadList(); }
  async function loadList() {
    const serial = ++state.listRequest;
    state.loading = true; state.error = null;
    const cached = read(key('cache-' + state.page));
    if (!state.list.length && cached) { state.list = cached.items || []; state.stale = true; }
    updateResults();
    try {
      const scope = state.page === 'mine' ? state.capabilities.coordinate ? 'all' : 'mine' : 'available';
      const data = await api('donations?scope=' + scope);
      if (serial !== state.listRequest) return;
      syncClock(data.server_time); state.list = Array.isArray(data.items) ? data.items : []; state.loading = false; state.stale = false; state.error = null;
      save(key('cache-' + state.page), {items:state.list,at:Date.now()});
      updateResults();
    } catch (error) { if (serial !== state.listRequest) return; state.error = error.message; state.loading = false; state.stale = !!state.list.length; updateResults(); }
  }
  function updateResults() { const status = document.getElementById('ra-list-status'); if (status) status.textContent = state.loading ? 'Actualizando…' : state.error ? 'Consulta sin actualizar' : visibleItems().length + (visibleItems().length === 1 ? ' donación' : ' donaciones'); const node = document.getElementById('ra-results'); if (node) node.innerHTML = results(); const demo = document.getElementById('ra-demo'); if (demo && (config.isDemo || state.list.some(i => i.is_demo))) demo.innerHTML = '<div class="ra-demo-banner">' + icon('info') + '<span>Datos de demostración. Estos alimentos no corresponden a ofertas reales.</span></div>'; }
  function notify(text) { clearTimeout(toastTimer); const n = document.getElementById('ra-toast-region'); if (!n) return; n.innerHTML = '<div class="ra-toast">' + icon('check') + '<span>' + esc(text) + '</span></div>'; toastTimer = setTimeout(() => { if (n) n.innerHTML = ''; }, 6000); }
  function openDialog(data) { state.lastFocus = document.activeElement; state.dialog = data; document.body.style.overflow = 'hidden'; renderDialog(true); }
  function closeDialog() { if (!state.dialog) return; state.dialog = null; const region = document.getElementById('ra-dialog-region'); if (region) { if(pickupMaps)pickupMaps.destroy(region);region.innerHTML = ''; } document.body.style.overflow = ''; if (state.lastFocus && document.contains(state.lastFocus)) state.lastFocus.focus({preventScroll:true}); state.lastFocus = null; }
  function dialogWrap(body, label) { return '<div class="ra-dialog-backdrop" data-action="backdrop"><section class="ra-dialog" role="dialog" aria-modal="true" aria-labelledby="ra-dialog-title" aria-label="' + esc(label || '') + '" tabindex="-1"><header class="ra-dialog-chrome"><span class="ra-dialog-context" aria-hidden="true">' + esc(settings.brand_name) + '</span><button class="ra-icon-button ra-close" data-action="close-dialog" aria-label="Cerrar ventana">' + icon('close') + '</button></header><div class="ra-dialog-scroll">' + body + '</div></section></div>'; }
  function renderDialog(focus) {
    const d = state.dialog; const region = document.getElementById('ra-dialog-region'); if (!d || !region) return; if(pickupMaps)pickupMaps.destroy(region);
    let body = '';
    if (d.type === 'loading') body = '<div class="ra-detail-body"><h2 id="ra-dialog-title">Consultando el rescate</h2><div class="ra-initial" style="min-height:150px"><span class="ra-loading-mark"></span><p>Esperando la confirmación del servidor…</p></div></div>';
    if (d.type === 'error') body = '<div class="ra-detail-body"><h2 id="ra-dialog-title">No pudimos consultar el rescate</h2><div class="ra-alert ra-alert-error" style="margin-top:20px">' + icon('info') + '<span>' + esc(d.message) + '</span></div><div class="ra-modal-buttons"><button class="ra-button ra-button-secondary" data-action="close-dialog">Cerrar</button>' + (d.id ? '<button class="ra-button" data-action="detail" data-id="' + Number(d.id) + '">Reintentar consulta</button>' : '') + '</div></div>';
    if (d.type === 'detail') body = detailBody(d.item);
    if (d.type === 'reserve') body = reserveBody(d.item);
    if (d.type === 'deliver') body = deliveryBody(d.item);
    if (d.type === 'help') body = helpBody();
    if (d.type === 'pickup-pin' && pickupMaps) body = pickupMaps.pickerHTML(d.values || {});
    region.innerHTML = dialogWrap(body);
    if (d.type === 'detail' && pickupMaps) pickupMaps.mountPlan(region.querySelector('.ra-pickup-plan'), d.item, settings);
    if (d.type === 'pickup-pin' && pickupMaps) pickupMaps.mountPicker(region.querySelector('.ra-pin-picker'), d.values || {}, point => { updatePickupPin(point);closeDialog();notify('Punto de recogida confirmado en tu borrador.'); });
    if (focus) { const dialog = region.querySelector('.ra-dialog'); if (dialog) dialog.focus({preventScroll:true}); }
  }
  function pickupPlan(item) {
    if (pickupMaps && typeof pickupMaps.planHTML === 'function') return pickupMaps.planHTML(item,settings);
    if (item.is_demo) return '<section class="ra-pickup-plan" aria-labelledby="ra-plan-title"><div class="ra-plan-heading"><span class="ra-plan-symbol">' + icon('map') + '</span><div><h3 id="ra-plan-title">Mapa de ejemplo · Cali</h3></div></div><p class="ra-plan-notice">Vista ilustrativa de la ciudad. No ubica al comercio ni representa una recogida real.</p><p class="ra-plan-notice">No pudimos cargar el mapa de la app. Puedes ampliar la vista pública o recargar para reintentar.</p><a class="ra-button ra-button-block" href="https://www.openstreetmap.org/#map=13/3.4516/-76.532" target="_blank" rel="noopener noreferrer">Ampliar mapa de ejemplo ' + icon('arrow') + '</a><button class="ra-link-button" data-action="reload-app">Recargar la app</button></section>';
    const destination = [item.pickup_address,item.pickup_area,settings.city].filter(Boolean).join(', ');
    const route = new URL('https://www.google.com/maps/dir/');route.searchParams.set('api','1');route.searchParams.set('destination',destination);
    return '<section class="ra-pickup-plan" aria-labelledby="ra-plan-title"><div class="ra-plan-heading"><span class="ra-plan-symbol">' + icon('map') + '</span><div><h3 id="ra-plan-title">Mapa y ruta de recogida</h3><p>' + esc(item.pickup_address || 'Confirma el punto con la coordinación.') + '</p></div></div><p class="ra-plan-notice">' + (item.is_demo ? 'Esta donación contiene datos ficticios. No se genera una ruta real.' : 'No pudimos cargar el mapa de la app. Puedes abrir la ruta por dirección o recargar para reintentar.') + '</p>' + (!item.is_demo && destination ? '<a class="ra-button ra-button-block" href="' + esc(route.href) + '" target="_blank" rel="noopener noreferrer">Abrir ruta en Maps ' + icon('arrow') + '</a>' : '') + '<button class="ra-link-button" data-action="reload-app">Recargar la app</button></section>';
  }
  function focusPickupPlan(openMap) {
    const section=mount.querySelector('.ra-pickup-plan');if(!section)return;
    section.setAttribute('tabindex','-1');try{section.scrollIntoView({block:'start',behavior:'auto'});}catch(_){section.scrollIntoView();}try{section.focus({preventScroll:true});}catch(_){section.focus();}
    const button=section.querySelector('[data-ra-map-action=load]');if(openMap&&button&&!button.disabled)button.click();
  }
  function detailBody(item) {
    const history = Array.isArray(item.history) && item.history.length ? item.history : [{ event:'available',status:'available',created_at:item.created_at }];
    const delivery = item.delivery || {};
    return '<div class="ra-detail-image"><img src="' + esc(imageFor(item.category)) + '" alt="" width="640" height="420">' + statusBadge(item) + '</div><div class="ra-detail-body"><p class="ra-detail-id">Donación ' + esc(donationId(item)) + (item.is_demo ? ' · Demostración' : '') + '</p><h2 id="ra-dialog-title">' + esc(item.title) + '</h2><p class="ra-detail-merchant">' + esc(item.merchant_name) + '</p><button class="ra-detail-map-shortcut" data-action="focus-map" aria-label="' + (item.is_demo ? 'Ver mapa de ejemplo de ' : 'Ver mapa y ruta de recogida de ') + esc(item.title) + '">' + icon('map') + (item.is_demo ? 'Mapa de ejemplo' : 'Mapa y ruta de recogida') + ' ' + icon('arrow') + '</button>' + (item.description ? '<p class="ra-detail-description">' + esc(item.description) + '</p>' : '') + '<div class="ra-detail-facts"><div class="ra-detail-fact">' + icon('box') + '<div><small>Cantidad de alimentos</small><strong>' + esc(quantity(item)) + '</strong></div></div><div class="ra-detail-fact">' + icon('clock') + '<div><small>Recoger antes de</small><strong>' + esc(formatDate(item.deadline)) + '</strong></div></div><div class="ra-detail-fact">' + icon('pin') + '<div><small>Punto de recogida</small><strong>' + esc(item.pickup_address) + (item.pickup_area ? '<br>' + esc(item.pickup_area) : '') + '</strong></div></div><div class="ra-detail-fact">' + icon('user') + '<div><small>' + (item.volunteer_name ? 'Voluntario de la recogida' : 'Categoría de alimentos') + '</small><strong>' + esc(item.volunteer_name || categories[item.category] || 'Alimentos') + '</strong></div></div></div>' + (item.assisted && state.capabilities.coordinate ? '<p class="ra-detail-description">Registro asistido por ' + esc(({phone:'llamada telefónica',sms:'mensaje SMS',web:'web / presencial'})[item.origin_channel] || item.origin_channel) + '.</p>' : '') + pickupPlan(item) + '<h3>El recorrido del rescate</h3><ol class="ra-timeline">' + history.map(event => '<li><span class="ra-timeline-dot">' + icon('check') + '</span><div><strong>' + esc(({available:'Donación publicada',reserved:'Recogida reservada',delivered:'Entrega confirmada'})[event.event || event.status] || statusNames[event.status] || 'Movimiento registrado') + '</strong><p>' + esc(formatDate(event.created_at)) + (event.actor_name ? ' · ' + esc(event.actor_name) : '') + '</p></div></li>').join('') + '</ol>' + (item.status === 'delivered' ? '<div class="ra-alert ra-alert-info">' + icon('check') + '<span>Recibió: <strong>' + esc(delivery.recipient_name || item.recipient_name || 'Organización receptora') + '</strong><br>Entrega: ' + esc(formatDate(delivery.delivered_at || item.delivered_at)) + (delivery.responsible_name || item.responsible_name ? '<br>Registró: ' + esc(delivery.responsible_name || item.responsible_name) : '') + '</span></div>' : '') + '<div id="ra-dialog-error" role="alert"></div><div class="ra-detail-actions">' + (item.status === 'available' && !expired(item) && state.capabilities.reserve ? '<button class="ra-button" data-action="reserve-confirm" data-id="' + Number(item.id) + '">Reservar esta recogida ' + icon('arrow') + '</button><p>Revisaremos de nuevo la disponibilidad antes de confirmar.</p>' : item.status === 'reserved' && state.capabilities.deliver ? '<button class="ra-button" data-action="deliver-open" data-id="' + Number(item.id) + '">Registrar entrega ' + icon('check') + '</button><p>Confirma primero que la organización receptora recibió los alimentos.</p>' : item.status === 'reserved' ? '<div class="ra-alert ra-alert-info">' + icon('shield') + '<span>Esta recogida ya tiene un voluntario asignado. La coordinación confirmará su entrega.</span></div>' : expired(item) ? '<div class="ra-alert">' + icon('clock') + '<span>La hora límite venció. Esta donación ya no se ofrece para reservar.</span></div>' : '') + '</div></div>';
  }
  function reserveBody(item) { const pending = read(key('reserve-' + item.id)); return '<div class="ra-detail-body"><p class="ra-detail-id">Donación ' + esc(donationId(item)) + '</p><h2 id="ra-dialog-title">¿Puedes realizar esta recogida?</h2><p class="ra-confirm-copy">Vas a reservar <strong>' + esc(item.title) + '</strong>, ' + esc(quantity(item)) + ', de ' + esc(item.merchant_name) + '.</p><div class="ra-detail-facts"><div class="ra-detail-fact">' + icon('pin') + '<div><small>Punto de recogida</small><strong>' + esc(item.pickup_address) + '</strong></div></div><div class="ra-detail-fact">' + icon('clock') + '<div><small>Hora límite</small><strong>' + esc(formatDate(item.deadline)) + '</strong></div></div></div><div class="ra-reserve-warning">' + icon('shield') + '<span>Al confirmar, la recogida queda asignada solo a ti. La disponibilidad se comprueba en el servidor.</span></div>' + (pending ? '<div class="ra-alert" style="margin-top:15px">' + icon('info') + '<span>Conservamos tu solicitud anterior. Reintenta para conocer su resultado.</span></div>' : '') + '<div id="ra-dialog-error" class="ra-form-error" role="alert"></div><div class="ra-modal-buttons"><button class="ra-button ra-button-secondary" data-action="detail-local">Volver al detalle</button><button class="ra-button" data-action="reserve-submit">' + (pending ? 'Reintentar reserva' : 'Confirmar mi reserva') + '</button></div></div>'; }
  function deliveryBody(item) {
    const pending = read(key('deliver-' + item.id)); const values = pending ? pending.form : {};
    return '<div class="ra-detail-body"><p class="ra-detail-id">Cierre de donación ' + esc(donationId(item)) + '</p><h2 id="ra-dialog-title">Confirma una buena entrega</h2><p class="ra-confirm-copy">' + esc(item.title) + ' · ' + esc(quantity(item)) + '<br>Comercio: ' + esc(item.merchant_name) + (item.volunteer_name ? '<br>Transportó: ' + esc(item.volunteer_name) : '') + '</p><form id="ra-delivery-form" class="ra-dialog-form" data-id="' + Number(item.id) + '" novalidate>' + (pending ? '<div class="ra-alert">' + icon('info') + '<span>Hay un cierre pendiente de confirmación. Reintenta con los mismos datos.</span></div>' : '') + '<fieldset class="ra-form-fields" style="border:0;padding:0;margin:0;min-width:0"' + (pending ? ' disabled' : '') + '><div class="ra-form-grid">' + field('recipient_name', 'Organización que recibió', 'text', values.recipient_name || '', {required:true,wide:true,max:180}) + field('picked_up_at', 'Fecha y hora de recogida', 'datetime-local', values.picked_up_at || '', {required:true,max:dateLocal(new Date(serverNow()).toISOString())}) + field('delivered_at', 'Fecha y hora de entrega', 'datetime-local', values.delivered_at || '', {required:true,max:dateLocal(new Date(serverNow()).toISOString())}) + field('responsible_name', 'Responsable que registra', 'text', values.responsible_name || state.user.name || '', {required:true,wide:true,max:180}) + field('notes', 'Observaciones de entrega', 'textarea', values.notes || '', {optional:true,wide:true,max:1800}) + '</div><label class="ra-checkbox" style="margin-top:19px"><input id="ra-received_confirmed" type="checkbox" name="received_confirmed" aria-describedby="ra-error-received_confirmed" required' + (values.received_confirmed ? ' checked' : '') + '><span>Confirmé con la organización receptora la capacidad, las condiciones y la recepción de estos alimentos.</span></label><span class="ra-field-error" id="ra-error-received_confirmed"></span></fieldset><div id="ra-dialog-error" class="ra-form-error" role="alert"></div><div class="ra-modal-buttons"><button class="ra-button ra-button-secondary" type="button" data-action="detail-local">Volver al detalle</button><button class="ra-button" type="submit">' + (pending ? 'Reintentar cierre' : 'Confirmar entrega') + '</button></div><p class="ra-draft-status">Horarios de Colombia (UTC−5). El cierre confirmado no se puede reemplazar.</p></form></div>';
  }
  function helpBody() { return '<div class="ra-detail-body"><h2 id="ra-dialog-title">De la donación a una nueva mesa</h2><p class="ra-confirm-copy">La comunidad se organiza para que los alimentos en buen estado lleguen a una organización que pueda recibirlos.</p><ol class="ra-how-list"><li><span class="ra-how-number">1</span><div><strong>El comercio comparte</strong><p>Publica el alimento, la cantidad, el punto de recogida y la hora límite. La coordinación también puede registrar solicitudes recibidas por llamada o SMS.</p></div></li><li><span class="ra-how-number">2</span><div><strong>Un voluntario reserva</strong><p>Revisa si puede realizar la recogida y confirma su reserva. Solo una persona puede quedar asignada a cada donación.</p></div></li><li><span class="ra-how-number">3</span><div><strong>La coordinación confirma</strong><p>Verifica la recepción y registra la recogida, la entrega y la organización receptora. El rescate cambia a Entregada.</p></div></li></ol><div class="ra-alert ra-alert-info" style="margin-top:24px">' + icon('info') + '<span>El estado siempre depende de una confirmación del servidor. Si se interrumpe la conexión, conserva tu solicitud y reintenta.</span></div><button class="ra-button ra-button-block" data-action="close-dialog">Entendido</button></div>'; }
  async function loadDetail(id, focusMap) { const previous = state.dialog && state.dialog.item; if (!state.dialog) openDialog({type:'loading',id}); else { state.dialog = {type:'loading',id,item:previous}; renderDialog(false); } try { const item = unwrap(await api('donations/' + Number(id))); if (!state.dialog || Number(state.dialog.id) !== Number(id)) return; state.dialog = {type:'detail',id,item}; renderDialog(!focusMap);if(focusMap)focusPickupPlan(true); } catch (error) { if (!state.dialog) return; state.dialog = {type:'error',id,message:error.message}; renderDialog(true); } }
  function dataFromForm(form) { const values = {}; new FormData(form).forEach((v,k) => { values[k] = v; }); values.food_safe = !!form.querySelector('[name=food_safe]:checked'); values.received_confirmed = !!form.querySelector('[name=received_confirmed]:checked'); return values; }
  function showFormError(form, error, target, focus) {
    form.querySelectorAll('[aria-invalid]').forEach(node => node.removeAttribute('aria-invalid'));
    form.querySelectorAll('.ra-field-error').forEach(node => { node.textContent = ''; });
    form.raError = {error,target};
    form.dataset.validationAttempted = 'true';
    const entries = Object.entries(error.fields || {});
    const box = document.getElementById(target);
    if (box) box.innerHTML = '<div class="ra-alert ra-alert-error">' + icon(error.uncertain ? 'offline' : 'info') + '<div><p>' + esc(error.message || 'Revisa los campos indicados y vuelve a intentar.') + '</p>' + (entries.length ? '<ul class="ra-error-list">' + entries.map(([name,message]) => {const input=form.elements.namedItem(name);const copy=esc((validation && validation.labels[name] || 'Campo del formulario') + ': ' + message);return '<li>' + (input && input.id && input.type !== 'hidden' ? '<a href="#' + esc(input.id) + '">' + copy + '</a>' : copy) + '</li>';}).join('') + '</ul>' : '') + '</div></div>';
    entries.forEach(([name,message]) => {
      const input = form.elements.namedItem(name);
      if (input && input.setAttribute) {
        input.setAttribute('aria-invalid','true');
        const describedBy = new Set(String(input.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean));
        describedBy.add('ra-error-' + name);
        input.setAttribute('aria-describedby',Array.from(describedBy).join(' '));
      }
      const node = document.getElementById('ra-error-' + name);
      if (node) node.textContent = String(message);
    });
    const first = form.querySelector('[aria-invalid=true]:not([type=hidden]):not(:disabled)');
    if (first && focus !== false) first.focus();
  }
  function validationError(message, fields) { return {message,fields:fields || {},uncertain:false}; }
  function validateForm(form, values) {
    if (!validation) return {message:'No se pudo cargar la validación del formulario. Tu borrador se conserva; recarga la página para reintentar.',fields:{},uncertain:false};
    let fields;
    if (form.id === 'ra-donation-form') fields = validation.validateDonation(values,serverNow(),!!state.capabilities.coordinate);
    else if (form.id === 'ra-delivery-form') fields = validation.validateDelivery(values,serverNow());
    else fields = validation.validateLookup(values.donation_id).fields;
    const amount = form.elements.namedItem('quantity');
    if (amount && amount.validity && amount.validity.badInput) fields.quantity = 'Escribe una cantidad numérica válida; por ejemplo, 1.5. No uses letras ni separadores de miles.';
    const total = Object.keys(fields).length;
    return total ? validationError(total === 1 ? 'Revisa el campo indicado antes de continuar.' : 'Revisa los ' + total + ' campos indicados antes de continuar.', fields) : null;
  }
  function updateFieldErrors(form, input) {
    if (!form.raError || !validation) return;
    const current = validateForm(form,dataFromForm(form));
    const fields = Object.assign({},form.raError.error.fields || {});
    const related = ['picked_up_at','delivered_at'].includes(input.name) ? ['picked_up_at','delivered_at'] : [input.name];
    related.forEach(name => { if (current && current.fields[name]) fields[name] = current.fields[name]; else delete fields[name]; });
    if (Object.keys(fields).length) {
      const total = Object.keys(fields).length;
      showFormError(form,validationError(total === 1 ? 'Revisa el campo indicado antes de continuar.' : 'Revisa los ' + total + ' campos indicados antes de continuar.',fields),form.raError.target,false);
    } else if (Object.keys(form.raError.error.fields || {}).length) {
      const target = form.raError.target;
      form.querySelectorAll('[aria-invalid]').forEach(node => node.removeAttribute('aria-invalid'));
      form.querySelectorAll('.ra-field-error').forEach(node => { node.textContent = ''; });
      const box = document.getElementById(target); if (box) box.innerHTML = '';
      form.raError = null;
    }
  }
  async function publish(form) {
    const pending = read(key('create-pending')); const values = pending ? pending.form : dataFromForm(form);
    if (!pending) { const error=validateForm(form,values);if(error){showFormError(form,error,'ra-form-error');return;} }
    const qty = Number(values.quantity);
    const payload = pending ? pending.payload : {title:values.title.trim(),description:values.description.trim(),category:values.category,quantity:qty,unit:values.unit,merchant_name:values.merchant_name.trim(),pickup_address:values.pickup_address.trim(),pickup_area:values.pickup_area.trim(),deadline:isoLocal(values.deadline),origin_channel:state.capabilities.coordinate ? values.origin_channel : 'web',assisted:!!state.capabilities.coordinate,request_key:requestKey()};
    const pin = pickupMaps && pickupMaps.coords(values);
    if (!pending && pin) {payload.pickup_latitude=pin[0];payload.pickup_longitude=pin[1];}
    const operation = pending || {form:values,payload}; save(key('create-pending'), operation); save(key('draft'), values);
    const button = form.querySelector('[type=submit]'); button.disabled = true; button.textContent = 'Confirmando publicación…';
    const fields = form.querySelector('fieldset'); fields.disabled = true;
    try { const item = unwrap(await api('donations',{method:'POST',body:JSON.stringify(payload)})); remove(key('create-pending')); remove(key('draft')); state.success = item; state.list = []; render(); window.scrollTo({top:0,behavior:'instant'}); }
    catch (error) { button.disabled = false; button.textContent = error.uncertain ? 'Reintentar publicación' : 'Publicar donación'; fields.disabled = !!error.uncertain; if (!error.uncertain) remove(key('create-pending')); showFormError(form,error,'ra-form-error'); }
  }
  async function reserve(button) {
    const d = state.dialog; if (!d || !d.item) return; const item = d.item; const pendingKey = key('reserve-' + item.id); const payload = read(pendingKey) || {request_key:requestKey()}; save(pendingKey,payload);
    button.disabled = true; button.textContent = 'Confirmando reserva…';
    try { const result = unwrap(await api('donations/' + item.id + '/reserve',{method:'POST',body:JSON.stringify(payload)})); remove(pendingKey); state.dialog = {type:'detail',id:result.id,item:result}; renderDialog(true); notify('Reserva confirmada. Esta recogida quedó asignada a ti.'); loadList(); }
    catch (error) { if (!state.dialog) return; button.disabled = false; button.textContent = error.uncertain ? 'Reintentar reserva' : 'Confirmar mi reserva'; if (!error.uncertain) remove(pendingKey); const n = document.getElementById('ra-dialog-error'); if (n) n.innerHTML = '<div class="ra-alert ra-alert-error">' + icon(error.uncertain ? 'offline' : 'info') + '<span>' + esc(error.message) + '</span></div>'; if (error.status === 409) { button.hidden = true; loadList(); } }
  }
  async function deliver(form) {
    const d = state.dialog; if (!d || !d.item) return; const item = d.item; const pendingKey = key('deliver-' + item.id); const pending = read(pendingKey); const values = pending ? pending.form : dataFromForm(form);
    if (!pending) { const error=validateForm(form,values);if(error){showFormError(form,error,'ra-dialog-error');return;} }
    const payload = pending ? pending.payload : {recipient_name:values.recipient_name.trim(),picked_up_at:isoLocal(values.picked_up_at),delivered_at:isoLocal(values.delivered_at),responsible_name:values.responsible_name.trim(),notes:values.notes.trim(),request_key:requestKey()}; save(pendingKey,pending || {form:values,payload});
    const button = form.querySelector('[type=submit]'); button.disabled = true; button.textContent = 'Confirmando entrega…'; const fields = form.querySelector('fieldset'); fields.disabled = true;
    try { const result = unwrap(await api('donations/' + item.id + '/deliver',{method:'POST',body:JSON.stringify(payload)})); remove(pendingKey); state.dialog = {type:'detail',id:result.id,item:result}; renderDialog(true); notify('Entrega confirmada. El rescate quedó completado.'); loadList(); }
    catch (error) { if (!state.dialog) return; button.disabled = false; button.textContent = error.uncertain ? 'Reintentar cierre' : 'Confirmar entrega'; fields.disabled = !!error.uncertain; if (!error.uncertain) remove(pendingKey); showFormError(form,error,'ra-dialog-error'); }
  }
  function updatePickupPin(point) {
    const form=document.getElementById('ra-donation-form');if(!form)return;
    form.elements.namedItem('pickup_latitude').value=point?point[0]:'';
    form.elements.namedItem('pickup_longitude').value=point?point[1]:'';
    const summary=document.getElementById('ra-pin-summary');if(summary)summary.textContent=point?'Punto confirmado en '+point.map(v=>Number(v).toFixed(6)).join(', ')+'.':'Ayuda al voluntario a encontrar la entrada correcta.';
    const clear=form.querySelector('[data-action=pickup-pin-clear]');if(clear)clear.hidden=!point;
    const choose=form.querySelector('[data-action=pickup-pin]');if(choose)choose.innerHTML=icon('pin')+(point?'Cambiar punto':'Marcar punto en mapa');
    save(key('draft'),dataFromForm(form));
  }
  mount.addEventListener('click', event => {
    const button = event.target.closest('[data-action]'); if (!button || !mount.contains(button)) return;
    const action = button.dataset.action;
    if (action === 'navigate') navigate(button.dataset.page);
    else if (action === 'refresh') loadList();
    else if (action === 'category') { state.category = button.dataset.category; const scroll = mount.querySelector('.ra-categories').scrollLeft; renderContent(); const c = mount.querySelector('.ra-categories'); if(c){c.scrollLeft=scroll;const active=c.querySelector('[aria-pressed=true]');if(active)active.focus({preventScroll:true});} }
    else if (action === 'status') { state.status = button.dataset.status; renderContent(); const active=mount.querySelector('.ra-tab[aria-pressed=true]');if(active)active.focus({preventScroll:true}); }
    else if (action === 'clear-filters') { state.search='';state.category='all';state.status='all';renderContent(); }
    else if (action === 'detail') loadDetail(Number(button.dataset.id));
    else if (action === 'map-detail') loadDetail(Number(button.dataset.id),true);
    else if (action === 'focus-map') focusPickupPlan(true);
    else if (action === 'reload-app') window.location.reload();
    else if (action === 'close-dialog' || action === 'backdrop' && event.target === button) closeDialog();
    else if (action === 'reserve-confirm' && state.dialog && state.dialog.item) { state.dialog.type='reserve';renderDialog(true); }
    else if (action === 'detail-local' && state.dialog && state.dialog.item) { state.dialog.type='detail';renderDialog(true); }
    else if (action === 'reserve-submit') reserve(button);
    else if (action === 'deliver-open' && state.dialog && state.dialog.item) { state.dialog.type='deliver';renderDialog(true); }
    else if (action === 'help') openDialog({type:'help'});
    else if (action === 'pickup-pin' && pickupMaps) {const form=document.getElementById('ra-donation-form');if(form&&!read(key('create-pending'))){const values=dataFromForm(form);save(key('draft'),values);openDialog({type:'pickup-pin',values});}}
    else if (action === 'pickup-pin-clear') updatePickupPin(null);
    else if (action === 'show-offers') { const n=document.getElementById('ra-search');if(n){n.focus();n.scrollIntoView({block:'center',behavior:window.matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});} }
  });
  mount.addEventListener('input', event => { const validationForm=event.target.closest('form');if(validationForm)updateFieldErrors(validationForm,event.target);if (event.target.id === 'ra-search') { state.search=event.target.value;updateResults(); } const form=event.target.closest('#ra-donation-form');if(form && !read(key('create-pending'))){save(key('draft'),dataFromForm(form));const n=document.getElementById('ra-draft-status');if(n)n.textContent='Borrador guardado en este dispositivo.';} });
  mount.addEventListener('change', event => { const validationForm=event.target.closest('form');if(validationForm)updateFieldErrors(validationForm,event.target);const form=event.target.closest('#ra-donation-form');if(form && !read(key('create-pending')))save(key('draft'),dataFromForm(form)); });
  mount.addEventListener('submit', event => { const form=event.target;if(form.id==='ra-donation-form'){event.preventDefault();publish(form);}else if(form.id==='ra-delivery-form'){event.preventDefault();deliver(form);}else if(form.id==='ra-lookup-form'){event.preventDefault();const values=dataFromForm(form);const error=validateForm(form,values);if(error){showFormError(form,error,'ra-lookup-error');return;}loadDetail(validation.validateLookup(values.donation_id).id);} });
  document.addEventListener('keydown', event => { if(!state.dialog)return;if(event.key==='Escape'){event.preventDefault();closeDialog();return;}if(event.key==='Tab'){const dialog=mount.querySelector('.ra-dialog');if(!dialog)return;const targets=Array.from(dialog.querySelectorAll('a[href],button:not(:disabled):not([hidden]),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')).filter(n=>n.getClientRects().length);if(!targets.length){event.preventDefault();dialog.focus();return;}const first=targets[0],last=targets[targets.length-1];if(event.shiftKey&&(document.activeElement===first||document.activeElement===dialog)){event.preventDefault();last.focus();}else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===dialog)){event.preventDefault();first.focus();}} });
  window.addEventListener('offline',()=>{state.offline=true;notify('Sin conexión. Las acciones esperan confirmación del servidor.');});
  window.addEventListener('online',()=>{state.offline=false;if(['explore','mine'].includes(state.page)&&uid())loadList();});
  async function start() { try { const data=await api('bootstrap');syncClock(data.server_time);state.user=data.user||null;state.capabilities=data.capabilities||{};Object.assign(settings,data.settings||{});if(data.nonce)config.nonce=data.nonce;if(/^#[0-9a-f]{6}$/i.test(settings.accent_color)){mount.style.setProperty('--ra-accent',settings.accent_color);const c=settings.accent_color.slice(1).match(/.{2}/g).map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4));const l=.2126*c[0]+.7152*c[1]+.0722*c[2];mount.style.setProperty('--ra-action-text',1.05/(l+.05)>=4.5?'#FFFFFF':'#000000');}state.loading=!!uid();render();if(uid())loadList(); } catch(error) {state.user=null;state.loading=false;render();const content=document.getElementById('ra-content');if(content)content.insertAdjacentHTML('afterbegin','<div class="ra-alert ra-alert-error" role="alert">'+icon('offline')+'<span>No pudimos verificar la sesión. Recarga la página o vuelve a ingresar.</span></div>');} }
  start();
})();
